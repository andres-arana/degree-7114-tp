
// salidaViajante.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <iostream>
using namespace std;
#include <fstream>
using std::ifstream;

#include <cmath>
#include <iomanip>



void main()
{
	struct linea
	{
		int nodo;
		char ciudad[50];
		char provincia[25];
		int posx;
		int posy;
	};
	linea ciudades[1500];
	char buffer [150], *parte1 ,*parte4,*parte5;
	int i = 0,cc,dparcial,dtotal,nodoactual,nodoant;

//CARGAR MAESTRO

	ifstream master ("maestrosantacruz.csv",ios::in);
	master.getline(buffer,149);
	while (!master.eof())
	{
		parte1 = strtok(buffer,";");
		ciudades[i].nodo = atoi( parte1 );
		
		strcpy(ciudades[i].ciudad,strtok(NULL,";"));
		strcpy(ciudades[i].provincia, strtok(NULL,";"));
		ciudades[i].posx = atoi( strtok(NULL,";"));
		ciudades[i].posy = atoi( strtok(NULL,";"));
		
		i++;
		master.getline(buffer,149);
	}
	master.close();
	cc=i;
  
     
//ABRIR CONCORD

ifstream ciclo ("santacruz.cyc",ios::in);
ofstream sale ("santacruz.txt",ios::out);
ciclo.getline(buffer,149);
cout<<buffer<<endl;
nodoactual = atoi(buffer);
cout<<nodoactual<<" ";
dparcial=0;
dtotal=0;
sale<<setw(5)<<nodoactual<<"  "<<setw(5)<<dparcial<<"   "<<setw(6)<<dtotal<<"  "<<setw(25)<<ciudades[nodoactual].provincia<<"  "<<ciudades[nodoactual].ciudad<<endl;
nodoant=nodoactual;

ciclo.getline(buffer,149);
while (!ciclo.eof())
{
	nodoactual = atoi(buffer);
	dparcial = sqrt(pow(((float)ciudades[nodoactual].posx-ciudades[nodoant].posx),2)
		           +pow(((float)ciudades[nodoactual].posy-ciudades[nodoant].posy),2));
	dtotal +=dparcial;
	sale<<setw(5)<<nodoactual<<"  "<<setw(5)<<dparcial<<"   "<<setw(6)<<dtotal<<"  "<<setw(25)<<ciudades[nodoactual].provincia<<"  "<<ciudades[nodoactual].ciudad<<endl;
	nodoant=nodoactual;
	ciclo.getline(buffer,149);
}
dparcial = sqrt(pow(((float)ciudades[0].posx-ciudades[nodoant].posx),2)
			   +pow(((float)ciudades[0].posy-ciudades[nodoant].posy),2));
dtotal +=dparcial;

sale<<setw(5)<<0<<"  "<<setw(5)<<dparcial<<"   "<<setw(6)<<dtotal<<" "<<setw(25)<<ciudades[0].provincia<<"  "<<ciudades[0].ciudad<<endl;
sale.close();
cin>>buffer;
}
